package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;
@Controller
//@RequestMapping(path = "/useraccount")
public class BookingController {

    @Autowired
    UserAccountRepository userAccountRepository;


    /*
     * Mapping url exmaple:
     * http://localhost:8080/userAccount/add?userName=Jerry&password=888888&email=
     * jerry@dev2qa.com
     * http://localhost:8080/userAccount/add?userName=Richard&password=888888&email=
     * richard@google.com
     */
    @RequestMapping(value = "/addUser", method = RequestMethod.GET)
    public ModelAndView users() {
        return new ModelAndView("addUser", "command", new UserAccount());

    }

    @ModelAttribute("users")
    public UserAccount createUserAccountModel() {
        return new UserAccount();
    }

    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public String addUser(@ModelAttribute("users") @Validated UserAccount addUser ,
                          Model model) {

        model.addAttribute ("username", addUser.getUsername());
        model.addAttribute("password", addUser.getPassword());
        model.addAttribute("email",addUser.getEmail());
        model.addAttribute("thing1", addUser.getThing1());
        model.addAttribute("thing2", addUser.getThing2());
        model.addAttribute("thing3", addUser.getThing3());
        model.addAttribute("firstname", addUser.getFirstname());
        model.addAttribute("lastname", addUser.getLastname());
        model.addAttribute("phone", addUser.getPhone());
        model.addAttribute("about", addUser.getAbout());
        UserAccount userAccount = new UserAccount();
        userAccount.setUsername(addUser.getUsername());
        userAccount.setPassword(addUser.getPassword());
        userAccount.setEmail(addUser.getEmail());
        userAccount.setThing1(addUser.getThing1());
        userAccount.setThing2(addUser.getThing2());
        userAccount.setThing3(addUser.getThing3());
        userAccount.setFirstname(addUser.getFirstname());
        userAccount.setLastname(addUser.getLastname());
        userAccount.setPhone(addUser.getPhone());
        userAccount.setAbout(addUser.getAbout());
        userAccountRepository.save(userAccount);
        return "users";
    }

    //-------------------------------------------------- login spring

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView user() {
        return new ModelAndView("login", "command", new UserAccount());

    }

    @ModelAttribute("user")
    public UserAccount createuseraccountmodel() {
        return new UserAccount();
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(@ModelAttribute("user") @Validated UserAccount login ,
                        Model model) {
        model.addAttribute("username", login.getUsername());
        model.addAttribute("password", login.getPassword());
        if (login.getUsername().equals("admin") && login.getPassword().equals("1111")) {
        return "addUser";
        }
        return "users";
    }
    /*------------------------------------------------
     * Mapping url exmaple: http://localhost:8080/userAccount/findAll
     */
    @RequestMapping (value="/all" , method = RequestMethod.GET)
    public String findall( Model model) {

        model.addAttribute("find", userAccountRepository.findAll());
        return "all";
    }


    /*
     * Mapping url exmaple:
     * http://localhost:8080/userAccount/findByName?userName=Jerry
     */
    @RequestMapping(value = "/findbyname", method = RequestMethod.GET)
    public ModelAndView finduser() {
        return new ModelAndView("findbyname", "command", new UserAccount());

    }

    @ModelAttribute("users")
    public UserAccount findByName() {
        return new UserAccount();
    }
    @PostMapping(path = "/findbyname")
    public String findByName(@ModelAttribute("users")UserAccount user ,
                             ModelMap model) {

        StringBuffer retBuf = new StringBuffer();
        model.addAttribute("username", user.getUsername());
        List<UserAccount> userAccountList = userAccountRepository.findByUsername(user.getUsername());

        if (userAccountList != null) {
            for (UserAccount userAccount : userAccountList) {
                model.addAttribute("username", userAccount.getUsername());
                model.addAttribute("password", userAccount.getPassword());
               model.addAttribute("email", userAccount.getEmail());
                userAccountRepository.save(userAccount);
            }
            return "users";
        }

        if (retBuf.length() == 0) {
            retBuf.append("No record find.");
        }

        return retBuf.toString();
    }

    @RequestMapping(value = "/findbycity", method = RequestMethod.GET)
    public ModelAndView findciti() {
        return new ModelAndView("findbycity", "command", new UserAccount());

    }

    @ModelAttribute("users")
    public UserAccount findByThing3() {
        return new UserAccount();
    }
    @PostMapping(path = "/findbycity")
    public String findByThing3(@ModelAttribute("users")UserAccount user ,
                             ModelMap model) {

        StringBuffer retBuf = new StringBuffer();
        model.addAttribute("thing3", user.getThing3());
        List<UserAccount> userAccountList = userAccountRepository.findByThing3(user.getThing3());

        if (userAccountList != null) {
            for (UserAccount userAccount : userAccountList) {
                model.addAttribute("username", userAccount.getUsername());
                model.addAttribute("password", userAccount.getPassword());
                model.addAttribute("email", userAccount.getEmail());
                userAccountRepository.save(userAccount);
            }
            return "users";
        }

        if (retBuf.length() == 0) {
            retBuf.append("No record find.");
        }

        return retBuf.toString();
    }

    /*
     * Mapping url exmaple:
     * http://localhost:8080/userAccount/findByNameAndPassword?userName=Jerry&
     * password=888888
     */
    @RequestMapping(value = "/findbehavandfav", method = RequestMethod.GET)
    public ModelAndView finduserbehav() {
        return new ModelAndView("findbehavandfav", "command", new UserAccount());

    }

    @ModelAttribute("users")
    public UserAccount findByThing1AndThing2() {
        return new UserAccount();
    }
    @PostMapping(path = "/findbehavandfav")

//thing1 means behavior thing2 means favorite
    public String findByThing1AndThing2(@ModelAttribute("users")UserAccount user ,
                                        ModelMap model) {

        StringBuffer retBuf = new StringBuffer();
        model.addAttribute("behavior", user.getThing1());
        model.addAttribute("favorite", user.getThing2());
        List<UserAccount> userAccountList = (List<UserAccount>) userAccountRepository
                .findByThing1AndThing2(user.getThing1(),user.getThing1());

        if (userAccountList != null) {
            for (UserAccount userAccount : userAccountList) {
                model.addAttribute("username", userAccount.getUsername());
                model.addAttribute("firstname", userAccount.getFirstname());
                model.addAttribute("email", userAccount.getEmail());
                model.addAttribute("behavior", userAccount.getThing1());
                model.addAttribute("favorite", userAccount.getThing2());
                model.addAttribute("city", userAccount.getThing3());
                userAccountRepository.save(userAccount);
            }
            return "users";
        }

        if (retBuf.length() == 0) {
            retBuf.append("No record find.");
        }

        return retBuf.toString();
    }

    /*
     * Mapping url exmaple:
     * http://localhost:8080/userAccount/updateUser?userName=Jerry&password=hello&
     * email=hello_jerry@gmail.com
     */
    @RequestMapping(value = "/update", method = RequestMethod.GET)
    public ModelAndView updateuser() {
        return new ModelAndView("update", "command", new UserAccount());

    }

    @ModelAttribute("users")
    public UserAccount updateUser() {
        return new UserAccount();
    }

    @PostMapping(path = "/update")
    public String updateUser(@ModelAttribute("users")UserAccount user ,
                             ModelMap model) {

        StringBuffer retBuf = new StringBuffer();
        model.addAttribute("username", user.getUsername());
        List<UserAccount> userAccountList = userAccountRepository.findByUsername(user.getUsername());

        if (userAccountList != null) {
            for (UserAccount userAccount : userAccountList) {
               model.addAttribute("email", userAccount.getEmail());
               if(userAccount.getEmail() !=null){
                   model.addAttribute("email", user.getEmail());
                   model.addAttribute("about", user.getAbout());
               model.addAttribute("thing1", user.getThing1());
                model.addAttribute("thing2", user.getThing2());
                   userAccount.setEmail(user.getEmail());
                   userAccount.setThing1(user.getThing1());
                   userAccount.setThing2(user.getThing2());
                   userAccount.setAbout(user.getAbout());
                userAccountRepository.save(userAccount);}
            }
            return "users";
        }

        retBuf.append("User data update successfully.");

        return retBuf.toString();
    }

    /*
     * Mapping url exmaple:
     * http://localhost:8080/userAccount/deleteByUserName?userName=Richard
     */
    @GetMapping(path = "/deleteByUserName")
    @ResponseBody
    public String deleteByUserName(@RequestParam String userName) {

        StringBuffer retBuf = new StringBuffer();

        userAccountRepository.deleteByUsername(userName);

        retBuf.append("User data has been deleted successfully.");

        return retBuf.toString();
    }

    /*
     * Mapping url exmaple:
     * http://localhost:8080/userAccount/deleteByUserNameAndPassword?userName=
     * Richard&password=888888
     */
    @GetMapping(path = "/deleteByUserNameAndPassword")
    @ResponseBody
    public String deleteByUserNameAndPassword(@RequestParam String userName, @RequestParam String password) {

        StringBuffer retBuf = new StringBuffer();

        userAccountRepository.deleteByUsernameAndPassword(userName, password);

        retBuf.append("User data has been deleted successfully.");

        return retBuf.toString();
    }


}